ANV Remote Handset NRH-1R H8/3672 firmware file details V1.6:

Experimental: Pins 19 & 20 go high when recording & should go low again at end of time period if meter not connected

Record period 5 minutes
ANVR5M.mot
Record period 10 minutes
ANVR10M.mot
Record period 15 minutes
ANVR15M.mot
Record period 20 minutes
ANVR20M.mot
Record period 30 minutes
ANVR30M.mot
Record period infinite
ANVRIT.mot
