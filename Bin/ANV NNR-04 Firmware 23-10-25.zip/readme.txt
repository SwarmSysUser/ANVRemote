ANV Remote Handset NRH-1R H8/3672 firmware file details V1.6 and NL-42/52 V1.0:

Record period 5 minutes
NL-32 = ANVR5M.mot
NL-52 = NL52R5M.mot
Record period 10 minutes
NL-32 = ANVR10M.mot
NL-52 = NL52R10M.mot
Record period 15 minutes
NL-32 = ANVR15M.mot
NL-52 = NL52R15M.mot
Record period 20 minutes
NL-32 = ANVR20M.mot
NL-52 = NL52R20M.mot
Record period 30 minutes
NL-32 = ANVR30M.mot
NL-52 = NL52R30M.mot
Record period infinite
NL-32 = ANVRIT.mot
NL-52 = ANVRIT.mot

NL-53 Remote V1.1 for H8/3672 NNR-04 with post trigger timer:

Record period 5 minutes
NL53R5M.mot
No post trigger timer
NL53R5M_0.mot
Record period 10 minutes
NL53R10M.mot
No post trigger timer
NL53R10M_0.mot
Record period 15 minutes
NL53R15M.mot
No post trigger timer
NL53R15M_0.mot
Record period 20 minutes
NL53R20M.mot
No post trigger timer
NL53R20M_0.mot
Record period 30 minutes
NL53R30M.mot
No post trigger timer
NL53R30M_0.mot
Record period infinite
NL53RIT.mot
No post trigger timer
NL53RIT_0.mot

